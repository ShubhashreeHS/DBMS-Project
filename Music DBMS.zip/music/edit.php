<?php 
ob_start();
include('db.php');
if(isset($_GET['id']))
{
  $id=$_GET['id'];
  if(isset($_POST['update']))
  {
  $eusername=$_POST['eUsername'];
  $ePassword=$_POST['ePassword'];
  
  $updated=mysqli_query("UPDATE sample SET 
		Username='$eusername', Password='$Password' WHERE id='$id'")or die();
  if($updated)
  {
  $msg="Successfully Updated!!";
  header('Location:index.php');
  }
}
}
ob_end_flush();
?>
<!DOCTYPE>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Edit form</title>
<link type="text/css" media="all" rel="stylesheet" href="style.css">
</head>

<body>
<?php 
  if(isset($_GET['id']))
  {
  $id=$_GET['id'];
  $getselect=mysqli_query("SELECT * FROM sample WHERE id='$id'");
  while($profile=mysqli_fetch_array($getselect))
  {
    $username=$profile['username'];
    $Password=$profile['Password'];
    
?>
<div class="display">
  <form action="" method="post" name="insertform">
    <p>
      <label for="name"  id="preinput"> Username</label>
      <input type="text" name="eusername" required placeholder="Enter your name" 
      value="<?php echo $username; ?>" id="inputid" />
    </p>
    <p>
      <label  for="email"  id="preinput"> Password</label>
      <input type="email" name="eusermail" required placeholder="Enter your Password" 
      value="<?php echo $Password; ?>" id="inputid" />
    </p>
    
    <p>
      <input type="submit" name="update" value="Update" id="inputid" />
    </p>
  </form>
</div>
<?php } } ?>
</body>
</html>